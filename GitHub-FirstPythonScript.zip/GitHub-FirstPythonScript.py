#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    File name: GitHub-FirstPythonScript.py
    Author: ENTER YOUR  NAME
    Description:  ENTER BRIEF DESCRIPTION
    Date created: ENTER TODAY'S DATE in MM/DD/YYYY FORMAT
    Python Version: 3.9.16
"""

# Import arcpy module and allow overwrites
import arcpy
arcpy.env.overwriteOutput = True